# ¡Quieres ser mi San Valentín! 💖
¡Hola! Soy [Mabel Olivera - @mabelolivera10]() y estoy encantada de conocerte.

## Acerca de mí👀
Soy una persona apasionada por mi profesión, con una excelente capacidad de organización y facilidad para trabajar en equipo. Me considero altamente adaptable a diferentes entornos y siempre enfocada en alcanzar objetivos. Además, poseo conocimientos en diversos lenguajes de programación como Java, Visual.NET, PHP, entre otros. Tengo un gran interés en el desarrollo de software y el análisis de sistemas.

🌱 Actualmente, estoy enfocada en seguir aprendiendo y mejorando mis habilidades en distintos lenguajes de programación.

## Colaboración💞
Estoy interesada en colaborar contigo en proyectos emocionantes y desafiantes. ¡Juntos podemos lograr grandes cosas!

## Contacto 📫
Puedes encontrarme en mis redes sociales:

- [Facebook](https://www.facebook.com/mabelquispeolivera/)
- [Instagram](https://www.instagram.com/mabelolivera10/)
- [TikTok](https://www.tiktok.com/@encodedmabel)
- [YouTube](https://www.youtube.com/@encodedmabel)
- [LinkedIn](https://www.linkedin.com/in/mabelquispeolivera/)
- [Twitter](https://twitter.com/mabel_Q_O)
- [CodeOpen](https://codepen.io/mabelolivera10)
- [Sitio Web](https://encoded.pe/)

¡Espero poder conectarme contigo pronto y colaborar en futuros proyectos! 😊